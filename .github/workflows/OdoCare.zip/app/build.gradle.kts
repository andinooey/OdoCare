plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.odocare.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.odocare.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 19
        versionName = "1.15.1"
        vectorDrawables { useSupportLibrary = true }
    }

    // Keystore ikut di repo (app/odocare-release.jks) supaya tanda tangan APK selalu sama dan update bisa menimpa versi lama.
    // Untuk memakai keystore lain tanpa mengubah file ini, isi variabel lingkungan ODOCARE_KEYSTORE_PASSWORD dan ODOCARE_KEY_PASSWORD.
    signingConfigs {
        create("release") {
            storeFile = file("odocare-release.jks")
            storePassword = System.getenv("ODOCARE_KEYSTORE_PASSWORD") ?: "odocare-rel-2026"
            keyAlias = "odocare"
            keyPassword = System.getenv("ODOCARE_KEY_PASSWORD") ?: "odocare-rel-2026"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            signingConfig = signingConfigs.getByName("release")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    // Lint "vital" ikut jalan di assembleRelease dan bisa menggagalkan build karena peringatan non-krusial
    lint { checkReleaseBuilds = false }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.06.00")
    implementation(composeBom)

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.2")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.2")
    implementation("androidx.activity:activity-compose:1.9.0")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.7.7")

    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    implementation("androidx.work:work-runtime-ktx:2.9.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    debugImplementation("androidx.compose.ui:ui-tooling")

    testImplementation("junit:junit:4.13.2")
}
