@file:OptIn(ExperimentalMaterial3Api::class)

package com.odocare.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.odocare.app.MainViewModel
import com.odocare.app.data.LegalDocument
import com.odocare.app.domain.Engines
import com.odocare.app.domain.IntervalUnit
import com.odocare.app.domain.Reminder
import com.odocare.app.domain.Reminders
import com.odocare.app.ui.*

/** Hasil isian form dokumen */
private data class DocForm(
    val type: String, val expiry: Long, val number: String?,
    val lastRenewed: Long?, val intervalValue: Int?, val intervalUnit: IntervalUnit?, val reminders: String
)

@Composable
fun DocumentsScreen(vm: MainViewModel, onBack: () -> Unit) {
    val docs by vm.documents.collectAsStateWithLifecycle()
    val vehicle by vm.activeVehicle.collectAsStateWithLifecycle()
    var showAdd by remember { mutableStateOf(false) }
    var editTarget by remember { mutableStateOf<LegalDocument?>(null) }
    var renewTarget by remember { mutableStateOf<LegalDocument?>(null) }
    var deleteTarget by remember { mutableStateOf<LegalDocument?>(null) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = NoInsets,
        topBar = { BackTopBar("Pajak & Dokumen", onBack) },
        floatingActionButton = { if (vehicle != null) AddFab { showAdd = true } }
    ) { pad ->
        if (vehicle == null) {
            NoVehicleState(vm, Modifier.padding(pad).padding(top = 48.dp))
        } else if (docs.isEmpty()) {
            EmptyState(Icons.Default.Description, "Belum ada dokumen", "Simpan pajak, STNK, SIM, atau asuransi agar jatuh temponya diingatkan.", Modifier.padding(pad).padding(top = 48.dp), actionLabel = "Tambah Dokumen", onAction = { showAdd = true })
        } else {
            LazyColumn(Modifier.padding(pad).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(top = 8.dp, bottom = 88.dp)) {
                items(docs, key = { it.id }) { d ->
                    val view = Engines.documentView(d)
                    val colors = docColor(view.status)
                    val unit = IntervalUnit.parse(d.intervalUnit)
                    StatusStripeCard(colors.second) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(docTypeLabel(d.type), Modifier.weight(1f), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                            StatusBadge(view.status.label, colors)
                            ItemMenu(onEdit = { editTarget = d }, onDelete = { deleteTarget = d })
                        }
                        Text("Jatuh tempo ${fmtDate(d.expiryDate)} · ${docDaysText(view.daysRemaining)}", fontSize = 12.sp, color = colors.second)
                        val meta = mutableListOf<String>()
                        if (!d.number.isNullOrBlank()) meta += "No. ${d.number}"
                        d.lastRenewedDate?.let { meta += "Diperpanjang ${fmtDate(it)}" }
                        if (d.intervalValue != null && unit != null) meta += "Berlaku ${d.intervalValue} ${unit.label.lowercase()}"
                        if (meta.isNotEmpty()) Text(meta.joinToString(" · "), fontSize = 11.sp, color = TextGray)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.NotificationsActive, null, tint = TextGray, modifier = Modifier.size(12.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(Reminders.summary(d.reminders), fontSize = 11.sp, color = TextGray, modifier = Modifier.weight(1f))
                            TextButton(onClick = { renewTarget = d }, contentPadding = PaddingValues(horizontal = 8.dp), modifier = Modifier.height(30.dp)) {
                                Icon(Icons.Default.Autorenew, null, tint = LavenderPrimary, modifier = Modifier.size(14.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Perpanjang", color = LavenderPrimary, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAdd) DocumentFormDialog("Tambah Dokumen", null, { showAdd = false }) { f ->
        vm.addDocument(f.type, f.expiry, f.number, f.lastRenewed, f.intervalValue, f.intervalUnit?.name, f.reminders); showAdd = false
    }
    editTarget?.let { d ->
        DocumentFormDialog("Edit Dokumen", d, { editTarget = null }) { f ->
            vm.updateDocument(d.copy(type = f.type, expiryDate = f.expiry, number = f.number, lastRenewedDate = f.lastRenewed, intervalValue = f.intervalValue, intervalUnit = f.intervalUnit?.name, reminders = f.reminders))
            editTarget = null
        }
    }
    renewTarget?.let { d -> RenewDialog(d, { renewTarget = null }) { renewed, newExpiry -> vm.renewDocument(d, renewed, newExpiry); renewTarget = null } }
    deleteTarget?.let { d -> ConfirmDialog("Hapus dokumen?", "${docTypeLabel(d.type)} akan dihapus beserta riwayat perpanjangannya.", "Hapus", { vm.deleteDocument(d.id); deleteTarget = null }, { deleteTarget = null }) }
}

private fun approxDays(r: Reminder): Int = r.value * when (r.unit) { IntervalUnit.DAY -> 1; IntervalUnit.MONTH -> 30; IntervalUnit.YEAR -> 365 }

/** Kotak info jatuh tempo hasil hitung otomatis. */
@Composable
private fun ExpiryInfo(text: String) {
    Surface(color = StatusBlueBg, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.EventAvailable, null, tint = StatusBlueText, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(10.dp))
            Text(text, fontSize = 13.sp, color = StatusBlueText, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun DocumentFormDialog(title: String, initial: LegalDocument?, onDismiss: () -> Unit, onSave: (DocForm) -> Unit) {
    var type by remember { mutableStateOf(initial?.type ?: docTypes.first().first) }
    var number by remember { mutableStateOf(initial?.number ?: "") }
    var lastRenewed by remember { mutableStateOf(initial?.lastRenewedDate) }
    var intervalText by remember { mutableStateOf(initial?.intervalValue?.toString() ?: "") }
    var intervalUnit by remember { mutableStateOf(IntervalUnit.parse(initial?.intervalUnit) ?: IntervalUnit.YEAR) }
    var manualExpiry by remember { mutableStateOf(initial?.expiryDate) }
    var reminders by remember { mutableStateOf(Reminders.parse(initial?.reminders ?: Reminders.DEFAULT)) }
    var newRemText by remember { mutableStateOf("") }
    var newRemUnit by remember { mutableStateOf(IntervalUnit.DAY) }

    // Jatuh tempo otomatis = tanggal terakhir perpanjang + interval (mis. 1/1/2026 + 1 tahun = 1/1/2027)
    val lr = lastRenewed
    val iv = posInt(intervalText)
    val computed: Long? = if (lr != null && iv != null) localDateToMillis(intervalUnit.plus(msToLocalDate(lr), iv)) else null
    val expiry: Long? = computed ?: manualExpiry

    FormDialog(
        title = title, icon = Icons.Default.Description, onDismiss = onDismiss, confirmEnabled = expiry != null,
        onConfirm = { expiry?.let { e -> onSave(DocForm(type, e, number.ifBlank { null }, lastRenewed, iv, if (iv != null) intervalUnit else null, Reminders.encode(reminders))) } }
    ) {
        DropdownField("Jenis dokumen", docTypeLabel(type), Icons.Default.Description, docTypes) { type = it }
        AppTextField(number, { number = it }, "Nomor dokumen (opsional)", Icons.Default.Pin)

        FormGroupLabel("Masa berlaku")
        DateField("Terakhir diperpanjang", lastRenewed) { lastRenewed = it }
        NumberField(intervalText, { intervalText = it }, "Berlaku selama", icon = Icons.Default.Update)
        UnitChips(intervalUnit) { intervalUnit = it }
        if (computed != null) {
            ExpiryInfo("Jatuh tempo ${fmtDate(computed)} (otomatis)")
        } else {
            DateField("Tanggal jatuh tempo", manualExpiry) { manualExpiry = it }
            FormNote("Isi \"Terakhir diperpanjang\" dan \"Berlaku selama\" agar jatuh tempo dihitung otomatis.")
        }

        FormGroupLabel("Ingatkan sebelum jatuh tempo")
        if (reminders.isEmpty()) FormNote("Hanya di hari jatuh tempo.")
        reminders.forEach { r ->
            Surface(color = SurfaceVariantDark.copy(alpha = 0.45f), shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, FieldBorder), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(start = 14.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.NotificationsActive, null, tint = LavenderPrimary, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(r.label(), Modifier.weight(1f), fontSize = 13.sp, color = TextWhite)
                    IconButton(onClick = { reminders = reminders - r }, modifier = Modifier.size(36.dp)) { Icon(Icons.Default.Close, "Hapus pengingat", tint = TextGray, modifier = Modifier.size(16.dp)) }
                }
            }
        }
        NumberField(newRemText, { newRemText = it }, "Ingatkan sebelum", icon = Icons.Default.AddAlert)
        UnitChips(newRemUnit) { newRemUnit = it }
        OutlinedButton(
            enabled = posInt(newRemText) != null, modifier = Modifier.fillMaxWidth().height(38.dp), shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, FieldBorder),
            onClick = {
                posInt(newRemText)?.let { v -> reminders = (reminders + Reminder(v, newRemUnit)).distinct().sortedByDescending { approxDays(it) } }
                newRemText = ""
            }
        ) { Icon(Icons.Default.Add, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text("Tambah pengingat", fontSize = 13.sp) }
    }
}

/** Perpanjang: pilih tanggal perpanjang; jatuh tempo baru = tanggal itu + interval dokumen (atau pilih manual bila tanpa interval). */
@Composable
private fun RenewDialog(doc: LegalDocument, onDismiss: () -> Unit, onConfirm: (renewedDate: Long, newExpiry: Long) -> Unit) {
    var renewed by remember { mutableStateOf(todayMillis()) }
    var manual by remember { mutableStateOf<Long?>(localDateToMillis(msToLocalDate(doc.expiryDate).plusYears(1))) }
    val iv = doc.intervalValue
    val unit = IntervalUnit.parse(doc.intervalUnit)
    val computed: Long? = if (iv != null && iv > 0 && unit != null) localDateToMillis(unit.plus(msToLocalDate(renewed), iv)) else null
    val unitLabel = unit?.label?.lowercase() ?: ""
    val newExpiry: Long? = computed ?: manual

    FormDialog(
        title = "Perpanjang", subtitle = docTypeLabel(doc.type), icon = Icons.Default.Autorenew, onDismiss = onDismiss, confirmEnabled = newExpiry != null,
        onConfirm = { newExpiry?.let { onConfirm(renewed, it) } }
    ) {
        DateField("Tanggal diperpanjang", renewed) { renewed = it }
        if (computed != null) ExpiryInfo("Jatuh tempo baru ${fmtDate(computed)} (berlaku $iv $unitLabel)")
        else DateField("Tanggal jatuh tempo baru", manual) { manual = it }
    }
}
