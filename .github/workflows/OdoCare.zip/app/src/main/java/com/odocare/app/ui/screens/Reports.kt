package com.odocare.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.odocare.app.MainViewModel
import com.odocare.app.data.OdometerLog
import com.odocare.app.ui.*
import com.odocare.app.util.Exports
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import kotlin.math.roundToInt

private enum class Period(val label: String) { MONTH("Bulan ini"), M3("3 bulan"), YEAR("Tahun ini"), M12("12 bulan"), ALL("Semua"), CUSTOM("Pilih tanggal") }

private fun Period.start(today: LocalDate): LocalDate? = when (this) {
    Period.MONTH -> today.withDayOfMonth(1)
    Period.M3 -> today.minusMonths(3)
    Period.YEAR -> today.withDayOfYear(1)
    Period.M12 -> today.minusMonths(12)
    Period.ALL -> null
    Period.CUSTOM -> null   // rentang kustom disimpan terpisah di layar
}

private fun fmtLocal(d: LocalDate): String = fmtDate(d.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli())

private data class KmStats(val avgPerMonth: Int?, val totalKm: Int, val days: Long, val perVehicle: List<Pair<String, Int>>)

/**
 * Rata-rata KM per bulan dari log odometer dalam rentang. Dihitung per kendaraan (jarak KM awal ke KM akhir / jumlah hari x 30),
 * lalu dijumlahkan agar KM kendaraan berbeda tidak tercampur. Kendaraan dengan kurang dari 2 catatan di rentang itu dilewati.
 */
private fun kmStats(logs: List<OdometerLog>, start: LocalDate?, end: LocalDate?): KmStats {
    var total = 0; var sumMonthly = 0.0; var maxDays = 0L
    val per = mutableListOf<Pair<String, Int>>()
    for ((vid, all) in logs.groupBy { it.vehicleId }) {
        val inRange = all.filter { val d = msToLocalDate(it.recordedAt); (start == null || !d.isBefore(start)) && (end == null || !d.isAfter(end)) }.sortedBy { it.recordedAt }
        if (inRange.size < 2) continue
        val first = inRange.first(); val last = inRange.last()
        val dist = (last.km - first.km).coerceAtLeast(0)
        val days = ChronoUnit.DAYS.between(msToLocalDate(first.recordedAt), msToLocalDate(last.recordedAt)).coerceAtLeast(1)
        val monthly = dist * 30.0 / days
        total += dist; maxDays = maxOf(maxDays, days); sumMonthly += monthly
        per += vid to monthly.roundToInt()
    }
    return KmStats(if (per.isEmpty()) null else sumMonthly.roundToInt(), total, maxDays, per)
}

@Composable
fun ReportScreen(vm: MainViewModel, onOpenHistory: () -> Unit) {
    val ctx = LocalContext.current
    val vehicles by vm.vehicles.collectAsStateWithLifecycle()
    val allRecords by vm.allRecords.collectAsStateWithLifecycle()
    var vehicleFilter by remember { mutableStateOf<String?>(null) }
    var period by remember { mutableStateOf(Period.YEAR) }
    var customStart by remember { mutableStateOf<LocalDate?>(null) }
    var customEnd by remember { mutableStateOf<LocalDate?>(null) }
    var showRangePicker by remember { mutableStateOf(false) }
    val allOdometer by vm.allOdometer.collectAsStateWithLifecycle()
    var info by remember { mutableStateOf<String?>(null) }

    val activeFilter = vehicleFilter?.takeIf { id -> vehicles.any { it.id == id } }
    val names = vehicles.associate { it.id to it.name }
    val byVehicle = allRecords.filter { activeFilter == null || it.vehicleId == activeFilter }
    val today = LocalDate.now()
    val custom = period == Period.CUSTOM
    val start = if (custom) customStart else period.start(today)
    val endBound = if (custom) customEnd else null   // batas akhir hanya untuk rentang kustom
    val records = byVehicle.filter { r -> val d = msToLocalDate(r.date); (start == null || !d.isBefore(start)) && (endBound == null || !d.isAfter(endBound)) }

    val total = records.sumOf { it.cost }
    val count = records.size
    val km = kmStats(allOdometer.filter { activeFilter == null || it.vehicleId == activeFilter }, start, endBound)
    val last = records.maxOfOrNull { it.date }
    val perCategory = records.groupBy { it.title }.mapValues { (_, l) -> l.sumOf { it.cost } }.toList().sortedByDescending { it.second }
    val perVehicle = records.groupBy { it.vehicleId }.mapValues { (_, l) -> l.sumOf { it.cost } }.toList().sortedByDescending { it.second }
    // Grafik mengikuti rentang yang dipilih ("Semua" mulai dari servis tertua)
    val series = if (records.isEmpty()) null else costSeries(records, start ?: records.minOf { msToLocalDate(it.date) }, endBound ?: today)

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(16.dp))
        // Ikon riwayat servis di kanan atas
        ScreenTitle("Laporan", "Ringkasan biaya servis") {
            IconButton(enabled = vehicles.isNotEmpty(), onClick = {
                activeFilter?.let { vm.setActiveVehicle(it) }
                onOpenHistory()
            }) { Icon(Icons.Default.History, "Riwayat servis", tint = if (vehicles.isNotEmpty()) LavenderPrimary else TextGray, modifier = Modifier.size(24.dp)) }
        }
        Spacer(Modifier.height(10.dp))

        if (vehicles.isEmpty()) {
            NoVehicleState(vm, Modifier.padding(top = 24.dp), "Tambahkan kendaraan dan catat servis untuk melihat laporan biaya.")
        } else {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = activeFilter == null, onClick = { vehicleFilter = null }, label = { Text("Semua", fontSize = 12.sp) })
                vehicles.forEach { v -> FilterChip(selected = activeFilter == v.id, onClick = { vehicleFilter = v.id }, label = { Text(v.name, fontSize = 12.sp) }) }
            }
            Spacer(Modifier.height(4.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Period.values().forEach { p ->
                    if (p == Period.CUSTOM) {
                        FilterChip(
                            selected = custom, onClick = { showRangePicker = true },
                            leadingIcon = { Icon(Icons.Default.CalendarMonth, null, modifier = Modifier.size(16.dp)) },
                            label = { Text(if (custom && customStart != null && customEnd != null) "${fmtLocal(customStart!!)} – ${fmtLocal(customEnd!!)}" else p.label, fontSize = 12.sp) }
                        )
                    } else FilterChip(selected = period == p, onClick = { period = p }, label = { Text(p.label, fontSize = 12.sp) })
                }
            }

            if (records.isEmpty()) {
                EmptyState(Icons.Default.BarChart, "Belum ada data servis", "Tidak ada servis pada periode ini. Catat servis dari tab Servis atau pilih periode lain.", Modifier.padding(top = 24.dp))
            } else {
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatCard(rupiah(total), "Total biaya", Modifier.weight(1f), Icons.Default.Payments)
                    StatCard("$count", "Jumlah servis", Modifier.weight(1f), Icons.Default.Build)
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatCard(km.avgPerMonth?.let { "${fmtKm(it)} km" } ?: "-", "Rata-rata KM / bulan", Modifier.weight(1f), Icons.Default.Speed)
                    StatCard(last?.let { fmtDate(it) } ?: "-", "Servis terakhir", Modifier.weight(1f), Icons.Default.Event)
                }
                // Keterangan rata-rata KM: dasar hitungan, atau alasan kenapa belum bisa dihitung
                Spacer(Modifier.height(4.dp))
                if (km.avgPerMonth == null) {
                    Text("Rata-rata KM butuh minimal 2 catatan KM pada periode ini.", color = TextGray, fontSize = 11.sp)
                } else {
                    val basis = when {
                        km.days < 7 -> "perkiraan, data baru ${km.days} hari"
                        km.perVehicle.size == 1 -> "dalam ${km.days} hari"
                        else -> "dari semua kendaraan"
                    }
                    Text("Dari ${fmtKm(km.totalKm)} km tercatat, $basis.", color = TextGray, fontSize = 11.sp)
                    if (km.perVehicle.size > 1) Text(km.perVehicle.joinToString(" · ") { (vid, v) -> "${names[vid] ?: "-"} ${fmtKm(v)}" } + " km/bulan", color = TextGray, fontSize = 11.sp)
                }

                Spacer(Modifier.height(16.dp))
                SectionHeader("Biaya per Kategori")
                Spacer(Modifier.height(4.dp))
                perCategory.forEach { (name, v) -> PercentBar(name, v, total) }

                if (perVehicle.size > 1) {
                    Spacer(Modifier.height(12.dp))
                    SectionHeader("Biaya per Kendaraan")
                    Spacer(Modifier.height(4.dp))
                    perVehicle.forEach { (vid, v) -> PercentBar(names[vid] ?: "-", v, total) }
                }

                Spacer(Modifier.height(12.dp))
                if (series != null) {
                    SectionHeader(series.title)
                    Spacer(Modifier.height(8.dp))
                    Surface(color = SurfaceVariantDark, shape = CardShape, modifier = Modifier.fillMaxWidth()) { Box(Modifier.padding(12.dp)) { BarChart(series.labels, series.values) } }
                }

                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Transaksi terbaru", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = TextWhite, modifier = Modifier.weight(1f))
                    TextButton(onClick = {
                        try { Exports.shareFile(ctx, "odocare-laporan.csv", "text/csv", Exports.csvBytes(records, vehicles)) } catch (e: Exception) { info = "Gagal mengekspor: ${e.message}" }
                    }, contentPadding = PaddingValues(horizontal = 8.dp), modifier = Modifier.height(30.dp)) {
                        Icon(Icons.Default.FileDownload, null, modifier = Modifier.size(16.dp), tint = LavenderPrimary)
                        Spacer(Modifier.width(4.dp))
                        Text("CSV", fontSize = 12.sp, color = LavenderPrimary)
                    }
                }
                Spacer(Modifier.height(4.dp))
                records.sortedByDescending { it.date }.take(50).forEach { r ->
                    Surface(color = SurfaceVariantDark, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 5.dp)) {
                        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(r.title, color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${fmtDate(r.date)} · ${names[r.vehicleId] ?: "-"} · ${fmtKm(r.km)} km", color = TextGray, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Spacer(Modifier.width(8.dp))
                            Text(if (r.cost > 0) rupiah(r.cost) else "-", color = LavenderPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
    if (showRangePicker) DateRangePickerDialogX(customStart, customEnd, { showRangePicker = false }) { s, e ->
        customStart = s; customEnd = e; period = Period.CUSTOM; showRangePicker = false
    }
    info?.let { InfoDialog(it) { info = null } }
}

